package com.cg.hotelMenu.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.hotelMenu.bean.Customer;
import com.cg.hotelMenu.bean.Dish;
import com.cg.hotelMenu.exception.HotelMenuException;
import com.cg.hotelMenu.util.DbConnection;

public class HotelMenuDaoImpl implements IHotelMenuDao {

	@Override
	public String addDish(Dish dish) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = DbConnection.getConnection();
		Statement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		String dishName = null;
		int queryResult = 0;

		try {

			preparedStatement = connection.prepareStatement("Insert into HotelMenu values(?,?)");

			preparedStatement.setString(1, dish.getDishName());

			preparedStatement.setInt(2, dish.getDishPrice());

			preparedStatement.executeUpdate();
			System.out.println("Inserted");
			statement = connection.createStatement();
			/*resultset = statement.executeQuery("select max(dish_Price) from HotelMenu");
			while (resultset.next()) {
				dishName = resultset.getString(1);

			}*/

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return dishName;
	}

	@Override
	public Dish viewDishDetails(String dishName) throws ClassNotFoundException, IOException, SQLException {
		Dish dish = null;
		Connection connection = DbConnection.getConnection();

		ResultSet resultset = null;
		Statement st = connection.createStatement();
		resultset = st.executeQuery("select * from HotelMenu where dish_Name='" + dishName + "'");
		while (resultset.next()) {
			dish = new Dish();
			dish.setDishName(resultset.getString(1));
			dish.setDishPrice(resultset.getInt(2));

		}
		return dish;
	}

	@Override
	public List retriveAll() throws ClassNotFoundException, IOException, SQLException {
		Connection con = DbConnection.getConnection();
		int dishCount = 0;

		PreparedStatement ps = null;
		ResultSet resultset = null;

		List<Dish> dishList = new ArrayList<Dish>();
		try {
			ps = con.prepareStatement("select * from hotelMenu ");
			resultset = ps.executeQuery();

			while (resultset.next()) {
				Dish dish = new Dish();
				dish.setDishName(resultset.getString(1));
				dish.setDishPrice(resultset.getInt(2));

				dishList.add(dish);

				dishCount++;
			}

		} catch (SQLException sqlException) {

			// throw new DonorException("Tehnical problem occured. Refer log");
			System.out.println(sqlException);
		}
		return dishList;
	}

	@Override
	public Dish updateDetails(int dishPrice, String dishName)
			throws ClassNotFoundException, IOException, SQLException, HotelMenuException {
		Connection connection = DbConnection.getConnection();
		ResultSet resultset = null;
		Statement st = connection.createStatement();
		PreparedStatement preparedStatement = null;
		Dish dish = null;
		try {
			preparedStatement = connection.prepareStatement("update  HotelMenu  SET dish_price=? where dish_Name= ?");
			preparedStatement.setString(2, dishName);
			preparedStatement.setInt(1, dishPrice);
			int i = preparedStatement.executeUpdate();
			System.out.println(dishName);
			resultset = st.executeQuery("select * from HotelMenu where dish_Name='" + dishName + "'");

			while (resultset.next()) {
				dish = new Dish();
				dish.setDishName(resultset.getString(1));
				dish.setDishPrice(resultset.getInt(2));
				return dish;

			}

		} catch (SQLException e) {
			// System.out.println(e);
			throw new HotelMenuException("Error in closing db connection");

		} finally {
			try {
				resultset.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				// System.out.println(e);
				throw new HotelMenuException("Error in closing db connection");

			}
		}
		return null;
	}
		@Override
		public boolean roomStaus() throws ClassNotFoundException, IOException, SQLException
		{
		try {
			
				Connection connection = DbConnection.getConnection();
				ResultSet resultset = null;
				Statement st = connection.createStatement();
				int count=0;
				resultset=st.executeQuery("select count(*) AS total from customer");
				//System.out.println(i);
				while(resultset.next())
				{
				count=resultset.getInt(1);
				if(count<=10)
					return true;
				}
				return false;
			}
		 catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;

}

	@Override
	public String addCustomerDetails(Customer customer) throws ClassNotFoundException, IOException, SQLException {
		// TODO Auto-generated method stub
		Connection connection = DbConnection.getConnection();
		Statement statement = null;
		PreparedStatement preparedStatement = null;
		ResultSet resultset = null;
		String customerId = null;
		int queryResult = 0;

		try {

			preparedStatement = connection.prepareStatement("Insert into Customer values(custId.nextval,?,?)");

			preparedStatement.setString(1, customer.getCustName());

			preparedStatement.setString(2, customer.getPhoneNumber());
			// preparedStatement.setString(3, customer.getAdharNumber());

			preparedStatement.executeUpdate();
			statement = connection.createStatement();
			resultset = statement.executeQuery("select cust_Id from customer");
			while (resultset.next()) {
				customer.setCustomerId(resultset.getString(1));
			}
			return customerId;
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return null;
	}

	

}
